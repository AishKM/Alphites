import spacy

# Load pre-trained NLP model
nlp = spacy.load("en_core_web_sm")

# Sample medical queries
queries = [
    "I have a headache and a sore throat.",
    "I've been feeling dizzy and have a fever.",
    "My stomach hurts and I have nausea."
]

# Define possible symptoms and advice
symptoms_dict = {
    "headache": "Take rest and stay hydrated. Over-the-counter pain relievers may help.",
    "sore throat": "Gargle with warm salt water and stay hydrated. Lozenges may provide relief.",
    "dizzy": "Sit or lie down until the dizziness passes. Drink plenty of fluids.",
    "fever": "Rest and drink plenty of fluids. Over-the-counter fever reducers may help.",
    "stomach hurts": "Avoid solid food for a few hours and drink clear fluids.",
    "nausea": "Stay hydrated and try eating small, bland meals."
}

def extract_symptoms(query):
    doc = nlp(query)
    symptoms = [token.text for token in doc if token.text in symptoms_dict]
    return symptoms

def provide_advice(symptoms):
    advice = [symptoms_dict[symptom] for symptom in symptoms]
    return advice

# Process each query
for query in queries:
    symptoms = extract_symptoms(query)
    advice = provide_advice(symptoms)
    print(f"Query: {query}")
    print(f"Identified Symptoms: {symptoms}")
    print(f"Advice: {advice}\n")

# Output can be used for backend purposes, e.g., storing symptoms in a database
