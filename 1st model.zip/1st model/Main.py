from tkinter import Tk
from tkinter import Tk, Frame, Button

from Landing.gui import Frame1
#from Last.gui import Medicine
from Last.gui1 import Medicine
from Last.gui2 import Setting
from Chatbot.chatbot import Frame3
from Dashboard.gui import Frame4
# Import other frames as needed

import subprocess

def run_script(script_path):
    """Runs a Python script using subprocess."""
    try:
        result = subprocess.run(['python', script_path], check=True, capture_output=True, text=True)
        print(f"Output of {script_path}:\n{result.stdout}")
    except subprocess.CalledProcessError as e:
        print(f"Error running {script_path}:\n{e.stderr}")

def main():
    scripts = [
        'Landing/gui.py',
        'Last/gui.py',
        'Last/gui1.py',
        'Last/gui2.py',
        'Chatbot/chatbot.py',
        'Dashboard/gui.py'
    ]

    for script in scripts:
        run_script(script)

if __name__ == "__main__":
    main()
